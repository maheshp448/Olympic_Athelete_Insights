-- 1. How many Olympics games have been held?
SELECT COUNT(DISTINCT games) AS Total_Olympic_Games 
FROM athlete_events;


-- 2. List down all Olympics games held so far. (Data issue at 1956-"Summer"-"Stockholm")
SELECT DISTINCT year, season, city
FROM athlete_events
ORDER BY year;


-- 3. Mention the total number of nations that participated in each Olympic game?
WITH all_countries AS (
    SELECT games, nr.region 
    FROM athlete_events ae 
    JOIN noc_regions nr ON nr.noc = ae.noc
    GROUP BY games, nr.region
)
SELECT games, COUNT(DISTINCT region) AS Total_Countries 
FROM all_countries
GROUP BY games
ORDER BY games;


-- 4. Which year saw the highest and lowest number of countries participating in the Olympics?
WITH all_countries AS (
    SELECT games, nr.region 
    FROM athlete_events ae 
    JOIN noc_regions nr ON nr.noc = ae.noc
    GROUP BY games, nr.region
), 
Tot_Countries AS (
    SELECT games, COUNT(DISTINCT region) AS Total_Countries 
    FROM all_countries
    GROUP BY games
)
SELECT
    CONCAT(FIRST_VALUE(games) OVER (ORDER BY total_countries), ' - ', FIRST_VALUE(total_countries) OVER (ORDER BY total_countries)) AS Lowest_Countries,
    CONCAT(FIRST_VALUE(games) OVER (ORDER BY total_countries DESC), ' - ', FIRST_VALUE(total_countries) OVER (ORDER BY total_countries DESC)) AS Highest_Countries
FROM Tot_Countries
ORDER BY 1;


-- 5. Which nation has participated in all of the Olympic games?
WITH tot_games AS (
    SELECT COUNT(DISTINCT games) AS total_games
    FROM athlete_events
), countries AS (
    SELECT games, nr.region AS country
    FROM athlete_events ae
    JOIN noc_regions nr ON nr.noc = ae.noc
    GROUP BY games, nr.region
), countries_participated AS (
    SELECT country, COUNT(DISTINCT games) AS total_participated_games
    FROM countries
    GROUP BY country
)
SELECT cp.*
FROM countries_participated cp
JOIN tot_games tg ON tg.total_games = cp.total_participated_games
ORDER BY 1;


-- 6. Identify the sport which was played in all summer Olympics.
WITH t1 AS (
    SELECT COUNT(DISTINCT games) AS Total_Summer_Games
    FROM athlete_events
    WHERE season = 'Summer'
),
t2 AS (
    SELECT DISTINCT sport, games
    FROM athlete_events
    WHERE season = 'Summer'
),
t3 AS (
    SELECT sport, COUNT(DISTINCT games) AS No_Of_Games 
    FROM t2
    GROUP BY sport
)
SELECT *
FROM t3
JOIN t1 ON t1.Total_Summer_Games = t3.No_Of_Games 
ORDER BY sport;


-- 7. Which Sports were just played only once in the Olympics.
WITH t1 AS (
    SELECT DISTINCT games, sport
    FROM athlete_events
),
t2 AS (
    SELECT sport, COUNT(DISTINCT games) AS No_Of_Games
    FROM t1
    GROUP BY sport
)
SELECT t2.*, t1.games
FROM t2
JOIN t1 ON t1.sport = t2.sport
WHERE t2.no_of_games = 1
ORDER BY t1.sport;


-- 8. Fetch the total no of sports played in each Olympic game.
WITH t1 AS (
    SELECT DISTINCT games, sport
    FROM athlete_events
),
t2 AS (
    SELECT games, COUNT(DISTINCT sport) AS No_Of_Sports
    FROM t1
    GROUP BY games
)
SELECT * FROM t2
ORDER BY No_Of_Sports DESC;


-- 9. Fetch oldest athletes to win a gold medal
WITH temp AS (
    SELECT name, sex, CAST(CASE WHEN age = 'NA' THEN '0' ELSE age END AS INT) AS age
            , team, games, city, sport, event, medal
    FROM athlete_events
),
ranking AS (
    SELECT *, RANK() OVER (ORDER BY age DESC) AS rnk
    FROM temp
    WHERE medal = 'Gold'
)
SELECT *
FROM ranking
WHERE rnk = 1;


-- 10. Find the Ratio of male and female athletes participated in all Olympic games.
WITH t1 AS (
    SELECT sex, COUNT(1) AS cnt
    FROM athlete_events
    GROUP BY sex
)
SELECT CONCAT('1 : ', ROUND(MAX(CASE WHEN sex = 'F' THEN cnt END) * 1.0 / NULLIF(MIN(CASE WHEN sex = 'M' THEN cnt END), 0), 2)) AS ratio
FROM t1;


-- 11. Top 5 athletes who have won the most gold medals.
WITH t1 AS (
    SELECT name, COUNT(1) AS Total_medals
    FROM athlete_events
    WHERE Medal = 'Gold'
    GROUP BY name
),
t2 AS (
    SELECT *, DENSE_RANK() OVER (ORDER BY Total_medals DESC) AS Rnk
    FROM t1
)
SELECT *
FROM t2
WHERE Rnk <= 5;


-- 12. Top 5 athletes who have won the most medals (gold/silver/bronze).
WITH t1 AS (
    SELECT name, COUNT(1) AS Total_medals
    FROM athlete_events
    WHERE Medal IN ('Gold', 'Silver', 'Bronze')
    GROUP BY name
),
t2 AS (
    SELECT *, DENSE_RANK() OVER (ORDER BY Total_medals DESC) AS Rnk
    FROM t1
)
SELECT *
FROM t2
WHERE Rnk <= 5;


-- 13. Top 5 most successful countries in Olympics. Success is defined by the number of medals won.
WITH t1 AS (
    SELECT nr.region, COUNT(1) AS Total_Medals
    FROM athlete_events ae
    JOIN noc_regions nr ON nr.noc = ae.noc
    WHERE medal <> 'NA'
    GROUP BY nr.region
),
t2 AS (
    SELECT *, DENSE_RANK() OVER (ORDER BY Total_Medals DESC) AS Rnk
    FROM t1
)
SELECT *
FROM t2
WHERE Rnk <= 5
ORDER BY Total_Medals DESC;


-- 14. List down total gold, silver, and bronze medals won by each country.
SELECT
    country,
    COALESCE(Gold, 0) AS Gold,
    COALESCE(Silver, 0) AS Silver,
    COALESCE(Bronze, 0) AS Bronze
FROM (
    SELECT
        nr.region AS country,
        medal,
        COUNT(1) AS total_medals
    FROM athlete_events ae
    JOIN noc_regions nr ON nr.noc = ae.noc
    WHERE medal <> 'NA'
    GROUP BY nr.region, medal
) AS Source
PIVOT(
    SUM(total_medals)
    FOR medal IN ([Gold], [Silver], [Bronze])
) AS


--  15. Which countries have never won a gold medal but have won silver/bronze medals?
SELECT *
FROM (
    SELECT
        country,
        COALESCE(Gold, 0) AS Gold,
        COALESCE(Silver, 0) AS Silver,
        COALESCE(Bronze, 0) AS Bronze
    FROM (
        SELECT
            nr.region AS country,
            medal,
            COUNT(1) AS total_medals
        FROM athlete_events ae
        JOIN noc_regions nr ON nr.noc = ae.noc
        WHERE medal <> 'NA'
        GROUP BY nr.region, medal
    ) AS Source
    PIVOT (
        SUM(total_medals)
        FOR medal IN ([Gold], [Silver], [Bronze])
    ) AS PivotTable
) x
WHERE Gold = 0 AND (Silver > 0 OR Bronze > 0)
ORDER BY Gold DESC, Silver DESC, Bronze DESC;

--  16. In which Sport/event, India has won the highest number of medals?
WITH t1 AS (
    SELECT sport, COUNT(1) AS Total_Medals
    FROM athlete_events
    WHERE medal <> 'NA'
    AND team = 'India'
    GROUP BY sport
),
t2 AS (
    SELECT sport, total_medals, RANK() OVER (ORDER BY total_medals DESC) AS Rnk
    FROM t1
)
SELECT sport, total_medals
FROM t2
WHERE Rnk = 1;


--  17.  Break down all Olympic games where India won medals for Hockey and the count of medals in each Olympic game.
SELECT team, sport, games, COUNT(1) AS Total_Medals
FROM athlete_events
WHERE medal <> 'NA'
    AND team = 'India'
    AND sport = 'Hockey'
GROUP BY team, sport, games
ORDER BY Total_Medals DESC;
